If you encounter bugs or issues contact me at: philipschen@hotmail.com 
with the subject: EASYCUT

Initial Setup Information, Warning: Advanced
1. Must set up a dataBase named: OptimizationDatabase with 3 tables: stockNew, stockUsed, and parts, table layouts must correspond with the included pictures. It is recommended to use microsoft sql manager 2014.
2.A. Download cutglib, from: http://www.optimalon.com/cutting_optimization_library.htm  and run the file 
2.B. Follow the instructions for using it as a COM object, for the cmd prompt use the visual studio developer console in adminstrative mode.
2.C. Register CutGlib (If you do not register, the trial lasts for 30 days after which the program will stop working)
2.D. Open the project file with visual studio 2015, free version is available from microsoft
2.E. ctrl+f (set selection to current project) "SetComputerLicenseKey". Uncomment the line and replace the string with the key from purchasing cutglib.
3.A. Make sure Excel and Adobe Acrobat are installed on the computer
3.B. If you are not using Excel 2013, then a reference must be added to the Excel object library, remove the original Excel reference and then Add Reference -> Excel, otherwise you may need to download the excel assembly.
3.C. If excel 2003 is being used it must be updated to SP3 or else input files will have to be converted to .xls, because excel 2003 without SP3 can not read .xlsx
4.A. Edit connection string in file class1, change datasource to the server name created
4.B. Datagridviews not in excel inputs must be revised so that the datasource points to the new database tables. ctrl+f (set selection to current project) Toshiba and replace the data source with your server name string, in the example below replace: TOSHIBA-2015\SQLEXPRESS.
Example Connection String:
Data Source=TOSHIBA-2015\SQLEXPRESS;Initial Catalog=OptimizationDatabase;Integrated Security=True
5. Right click the project and select build solution. Then right click the project and select open folder in file explorer. Select Bin, then select Debug, Create a shortcut for the application that is named Optimization and place it where you want to launch it from.


Notes for EasyCut
1.A. When first inputing stock, it is recommended to first use the input stock from excel button before import from Nav due to Nav not containing the size of each stock.
1.B. In practice, it is possible to use newstock input as a formatter, and use Nav input for actual number inputs. Just set the count column to 0 in the newstock input, and the nav input will replace the count with the nav count.

2. All inputs should preferably be typed in ALL CAPS

3.A. When editing the Excel files for import...
3.B. Required Fields: ID2, Description, size, count
3.C. Additional Notes: Count must be an integer, size must be a number, Context2 (Minimum Save Size) must be an integer.
3.D. Column order must stay the same.
3.E. The way that Excel input works is it updates any entries that match in the database, then adds any entries from the excel that are not in the database.

4. It is recommended to confirm that all the sizes of the stocks are in fact correct, and to export the NewStock as an excel file for future formatting use.

5. Remainder parts greater than 24 inches are automatically added to used parts list. Implenting a storage plan for them is recommended. The minimum size for saving a used part can be changed by editing the value in the excel import.

6. If any Excel input freezes initially, it is likely because a conversion message popped up in Excel, click yes to the message box. It may be behind the easycut program, if it is, minimize all windows then maximise all windows to bring it up. This can be done by clicking the lower right corner of the screen in windows 10.